#pragma once
#pragma comment(lib, "Ws2_32.lib")
#include <ws2tcpip.h>
#include "WinSock2.h"
#include <ws2def.h>
#include <codecvt>
#include <locale>

#include<windows.h>
#include <windowsX.h>
#include <tchar.h>
#include <fstream>
#include"resource.h"

using namespace std;