#include "Socket.h"

Socket::Socket()
{
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != NO_ERROR)
	{
		MessageBox(NULL, L"Error", L"WSAStratup error", MB_OK);
		WSACleanup();
		exit(10);
	}

	_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (_socket == INVALID_SOCKET)
	{
		MessageBox(NULL, L"Error", L"Socket create error", MB_OK);
		WSACleanup();
		exit(11);
	}
}

Socket::~Socket()
{
	WSACleanup();
}

bool Socket::SendData(char* buffer)
{
	send(_socket, buffer, strlen(buffer), 0);
	return true;
}

bool Socket::ReceiveData(char* buffer, int size)
{
	int i = recv(_socket, buffer, size, 0);
	buffer[i] = '\0';
	return true;
}

void Socket::CloseConnection()
{
	closesocket(_socket);
}

void ServerSocket::StartHosting(int port1)
{
	Bind(port1);

	Listen();
}

void ServerSocket::Listen()
{

	if (listen(_socket, 1) == SOCKET_ERROR)
	{
		MessageBox(NULL, L"Error", L"Listen error", MB_OK);
		WSACleanup();
		exit(15);
	}
	acceptSocket = accept(_socket, NULL, NULL);
	
	while (acceptSocket == SOCKET_ERROR)
	{
		acceptSocket = accept(_socket, NULL, NULL);
	}
	_socket = acceptSocket;
}

void ServerSocket::Bind(int port1)
{
	addr.sin_family = AF_INET;

	inet_pton(AF_INET, "0.0.0.0", &addr.sin_addr);
	addr.sin_port = htons(port1);

	if (bind(_socket, (SOCKADDR*)&addr, sizeof(addr)) == SOCKET_ERROR)
	{
		MessageBox(NULL, L"Error", L"Failer to bind to port", MB_OK);
		WSACleanup();
		exit(14);
	}

}

void ClientSocket::ConnectToServer(const char* ipAdress1, int port1)
{
	addr.sin_family = AF_INET;
	inet_pton(AF_INET, ipAdress1, &addr.sin_addr);
	addr.sin_port = htons(port1);
	if (connect(_socket, (SOCKADDR*)&addr, sizeof(addr)) == SOCKET_ERROR)
	{
		MessageBox(NULL, L"Error", L"Failer to bind to port", MB_OK);
		WSACleanup();
		exit(13);
	}
}