#include "Server.h"
#include "Socket.h"


ServerDlg* ServerDlg::ptr = NULL;
HWND ServerDlg::hAddDialog = NULL;
using namespace std;

bool IsEnd = false;
int port1 = 52963;
ServerSocket Server_Socket;



ServerDlg::ServerDlg(void)
{
	ptr = this;
}

ServerDlg::~ServerDlg(void)
{

}

void ServerDlg::Cls_OnClose(HWND hwnd)
{
	DestroyWindow(hwnd);
	hAddDialog = NULL;
}

DWORD WINAPI ReadThreadServer(LPVOID lp)
{
	
	HWND hEdit = (HWND)lp;
	char buff[MAXSTRLEN];
	wchar_t str[MAXSTRLEN];
	while (true)
	{
		Server_Socket.ReceiveData(buff, MAXSTRLEN);
		MultiByteToWideChar(CP_UTF8, 0, buff, -1, str, MAXSTRLEN);
		if (!wcscmp(str, L"END"))
		{
			Server_Socket.CloseConnection();
			IsEnd = true;
			return 0;
		}
		SendMessage(hEdit, EM_REPLACESEL, 0, (LPARAM)str);
		SendMessage(hEdit, EM_REPLACESEL, 0, (LPARAM)L"\r\n");
	}
}

void ServerDlg::Cls_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	hEdit1 = GetDlgItem(hwnd, IDC_EDIT1);
	hEdit2 = GetDlgItem(hwnd, IDC_EDIT2);
	static HANDLE Handle;
	static char buf[MAXSTRLEN];
	static int i;
	static wchar_t str[MAXSTRLEN];
	static bool isRecieving = true;
	if (id == IDC_BUTTON1)
	{
		Server_Socket.StartHosting(port1);
		Handle = CreateThread(NULL, 0, ReadThreadServer, hEdit2, 0, NULL);
	}
	if (id == IDC_BUTTON2)
	{
		GetWindowText(hEdit1, str, MAXSTRLEN);
		WideCharToMultiByte(CP_UTF8, 0, str, -1, buf, MAXSTRLEN, NULL, NULL);
		Server_Socket.SendData(buf);
	}
	if (id == IDC_BUTTON3)
	{
		Server_Socket.SendData("END");
		Server_Socket.CloseConnection();
		TerminateThread(Handle, 0);
		CloseHandle(Handle);
		DestroyWindow(hwnd);
	}
}

BOOL ServerDlg::Cls_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{

	hDialog = hwnd;
	
	return TRUE;
}


BOOL CALLBACK ServerDlg::DlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		HANDLE_MSG(hwnd, WM_CLOSE, ptr->Cls_OnClose);
		HANDLE_MSG(hwnd, WM_INITDIALOG, ptr->Cls_OnInitDialog);
		HANDLE_MSG(hwnd, WM_COMMAND, ptr->Cls_OnCommand);
	}
	if (IsEnd)
	{
		DestroyWindow(hwnd);
	}
	return FALSE;
}