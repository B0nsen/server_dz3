#include "CodingThreadDlg.h"
#include "Server.h"
#include "Client.h"



CodingThreadDlg* CodingThreadDlg::ptr = NULL;


using namespace std;



CodingThreadDlg::CodingThreadDlg(void)
{
	ptr = this;
}

CodingThreadDlg::~CodingThreadDlg(void)
{

}

void CodingThreadDlg::Cls_OnClose(HWND hwnd)
{
	DestroyWindow(hwnd);
}

void CodingThreadDlg::Cls_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{

	if (id == IDC_BUTTON1)
	{
		ServerDlg server;
		if (ServerDlg::hAddDialog)
		{
			SetForegroundWindow(ServerDlg::hAddDialog);
			return;
		}
		ServerDlg::hAddDialog = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG2), hwnd, ServerDlg::DlgProc);
		ShowWindow(ServerDlg::hAddDialog, SW_RESTORE);
	}
	if (id == IDC_BUTTON2)
	{
		ClientDlg client;
		if (ClientDlg::hAddDialog)
		{
			SetForegroundWindow(ClientDlg::hAddDialog);
			return;
		}
		ClientDlg::hAddDialog = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_DIALOG3), hwnd, ClientDlg::DlgProc);
		ShowWindow(ClientDlg::hAddDialog, SW_RESTORE);
	}
}

BOOL CodingThreadDlg::Cls_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam) 
{
	hDialog = hwnd;
	return TRUE;
}


BOOL CALLBACK CodingThreadDlg::DlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		HANDLE_MSG(hwnd, WM_CLOSE, ptr->Cls_OnClose);
		HANDLE_MSG(hwnd, WM_INITDIALOG, ptr->Cls_OnInitDialog);
		HANDLE_MSG(hwnd, WM_COMMAND, ptr->Cls_OnCommand);
	}
	return FALSE;
}