#pragma once
#pragma comment(lib, "Ws2_32.lib")
#include <ws2tcpip.h>
#include "WinSock2.h"
#include <ws2def.h>

#include <windowsx.h>
#include<windows.h>
#include <tchar.h>
#include <fstream>
#include"resource.h"
#include <codecvt>
#include <locale>
#include <iostream>



using namespace std;