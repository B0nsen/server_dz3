#include "Client.h"
#include "Socket.h"


ClientDlg* ClientDlg::ptr = NULL;
HWND ClientDlg::hAddDialog = NULL;

using namespace std;

int port = 52963;
bool isEnd = false;

ClientSocket Client_Socket;



ClientDlg::ClientDlg(void)
{
	ptr = this;
}

ClientDlg::~ClientDlg(void)
{

}

void ClientDlg::Cls_OnClose(HWND hwnd)
{
	DestroyWindow(hwnd);
	hAddDialog = NULL;
}

DWORD WINAPI ReadThreadClient(LPVOID lp)
{
	HWND hEdit = (HWND)lp;
	char buff[MAXSTRLEN];
	wchar_t str[MAXSTRLEN];
	while (true)
	{
		Client_Socket.ReceiveData(buff, MAXSTRLEN);
		MultiByteToWideChar(CP_UTF8, 0, buff, -1, str, MAXSTRLEN);
		if (!wcscmp(str, L"END"))
		{
			Client_Socket.CloseConnection();
			isEnd = true;
			return 0;
		}
		SendMessage(hEdit, EM_REPLACESEL, 0, (LPARAM)str);
		SendMessage(hEdit, EM_REPLACESEL, 0, (LPARAM)L"\r\n");
	}
	
}

void ClientDlg::Cls_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	hEdit1 = GetDlgItem(hwnd, IDC_EDIT1);
	hEdit2 = GetDlgItem(hwnd, IDC_EDIT2);
	static HANDLE Handle;
	static char buf[MAXSTRLEN];
	static int i;
	static wchar_t str[MAXSTRLEN];
	static bool isRecieving = true;
	if (id == IDC_BUTTON1)
	{
		GetWindowText(hEdit1, str, MAXSTRLEN);
		WideCharToMultiByte(CP_UTF8, 0, str, -1, buf, MAXSTRLEN, NULL, NULL);
		Client_Socket.ConnectToServer("127.0.0.1", port);
		Handle = CreateThread(NULL, 0, ReadThreadClient, hEdit2, 0, NULL);
	}
	if (id == IDC_BUTTON2)
	{
		GetWindowText(hEdit1, str, MAXSTRLEN);
		WideCharToMultiByte(CP_UTF8, 0, str, -1, buf, MAXSTRLEN, NULL, NULL);
		Client_Socket.SendData(buf);
	}
	if (id == IDC_BUTTON3)
	{
		Client_Socket.SendData("END");
		Client_Socket.CloseConnection();
		TerminateThread(Handle, 0);
		CloseHandle(Handle);
		DestroyWindow(hwnd);
	}
}

BOOL ClientDlg::Cls_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{

	hDialog = hwnd;
	return TRUE;
}


BOOL CALLBACK ClientDlg::DlgProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		HANDLE_MSG(hwnd, WM_CLOSE, ptr->Cls_OnClose);
		HANDLE_MSG(hwnd, WM_INITDIALOG, ptr->Cls_OnInitDialog);
		HANDLE_MSG(hwnd, WM_COMMAND, ptr->Cls_OnCommand);
	}
	if (isEnd)
	{
		DestroyWindow(hwnd);
	}
	return FALSE;
}